
let dark = document.getElementById('theme-btn');


dark.addEventListener("click",Dark);

var element = document.querySelector("body").classList;

function Dark() {
    element.toggle("theme2");
}


